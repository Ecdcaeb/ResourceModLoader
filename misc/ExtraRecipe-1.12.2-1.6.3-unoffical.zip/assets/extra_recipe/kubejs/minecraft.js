onEvent('recipes.crafting_table', event => {
      event.addShaped(
        'test:one',
        'minecraft:diamond',
        [
        'A'
        ],
        'A','minecraft:dirt'
      )
})