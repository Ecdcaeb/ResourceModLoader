onEvent('recipes', event => {
  event.shaped('3x minecraft:diamond', [
    'SAS',
    'S S',
    'SAS'
  ], {
    S: 'minecraft:dirt',
    A: 'minecraft:dirt'
  })
})